# CodeEmpire Gift Website


# 1. Install Node
# 2. Start install.bat
# 3. Start start.bat
# 4. Join localhost



**Made with ❤️ by vKhalid**
**Discord:** https://discord.gg/f69pqxVW2Y 